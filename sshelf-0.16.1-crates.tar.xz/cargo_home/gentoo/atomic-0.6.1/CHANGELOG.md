# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.6.1](https://github.com/Amanieu/atomic-rs/compare/v0.6.0...v0.6.1) - 2025-06-19

### Other

- Implement (de)serialization with `serde`.
